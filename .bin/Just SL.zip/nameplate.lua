local config = {
   from = "#ea323c",
   to = "#571c27",
}

for key, value in pairs(config) do
   config[key] = vectors.hexToRGB(value)
end

for key, value in pairs(config) do
   config[key] = vectors.rgbToHSV(value)
end

events.ENTITY_INIT:register(function()
   local composite = '['
   local name = player:getName()
   for i = 1, #name, 1 do
      local percentage = i/#name
      composite = composite.."{'text':'"..name:sub(i,i).."','color':'#"..vectors.rgbToHex(vectors.hsvToRGB(math.lerp(config.from,config.to,percentage))).."'}"
      if i ~= #name then
         composite = composite..","
      end
   end
   composite = composite.."]"
   nameplate.ALL:setText(composite)
end)