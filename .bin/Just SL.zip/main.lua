vanilla_model.ARMOR:setVisible(false)
vanilla_model.HELMET_ITEM:setVisible(true)
nameplate.ENTITY.shadow = true

vanilla_model.ELYTRA:setVisible(false)
vanilla_model.HAT:setVisible(false)
vanilla_model.PLAYER:setVisible(false)

models.sl.Head.mouth:setUV(0,1/11)

local root = action_wheel:newPage()

root:newAction():title("Wave"):item("minecraft:paper").leftClick = function ()
   pings.wave()
end

function pings.wave()
   animations.sl.wave:play()
end

action_wheel:setPage(root)